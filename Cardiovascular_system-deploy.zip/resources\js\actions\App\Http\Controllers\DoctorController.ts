import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/doctor/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
export const emr = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emr.url(options),
    method: 'get',
})

emr.definition = {
    methods: ["get","head"],
    url: '/doctor/emr',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.url = (options?: RouteQueryOptions) => {
    return emr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emr.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: emr.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
    const emrForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: emr.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
        emrForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emr.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
        emrForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emr.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    emr.form = emrForm
/**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
export const patientHistory = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientHistory.url(args, options),
    method: 'get',
})

patientHistory.definition = {
    methods: ["get","head"],
    url: '/doctor/patients/{patient}/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
patientHistory.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { patient: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    patient: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        patient: typeof args.patient === 'object'
                ? args.patient.id
                : args.patient,
                }

    return patientHistory.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
patientHistory.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientHistory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
patientHistory.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: patientHistory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
    const patientHistoryForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: patientHistory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
        patientHistoryForm.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientHistory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::patientHistory
 * @see app/Http/Controllers/DoctorController.php:282
 * @route '/doctor/patients/{patient}/history'
 */
        patientHistoryForm.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientHistory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    patientHistory.form = patientHistoryForm
/**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
export const patientAnalytics = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientAnalytics.url(args, options),
    method: 'get',
})

patientAnalytics.definition = {
    methods: ["get","head"],
    url: '/doctor/patients/{patient}/analytics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
patientAnalytics.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { patient: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    patient: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        patient: typeof args.patient === 'object'
                ? args.patient.id
                : args.patient,
                }

    return patientAnalytics.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
patientAnalytics.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientAnalytics.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
patientAnalytics.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: patientAnalytics.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
    const patientAnalyticsForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: patientAnalytics.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
        patientAnalyticsForm.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientAnalytics.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::patientAnalytics
 * @see app/Http/Controllers/DoctorController.php:161
 * @route '/doctor/patients/{patient}/analytics'
 */
        patientAnalyticsForm.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientAnalytics.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    patientAnalytics.form = patientAnalyticsForm
const DoctorController = { dashboard, emr, patientHistory, patientAnalytics }

export default DoctorController
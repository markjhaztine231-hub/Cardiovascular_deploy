import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
export const downloadMonthlyReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadMonthlyReport.url(options),
    method: 'get',
})

downloadMonthlyReport.definition = {
    methods: ["get","head"],
    url: '/doctor/reports/monthly/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
downloadMonthlyReport.url = (options?: RouteQueryOptions) => {
    return downloadMonthlyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
downloadMonthlyReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadMonthlyReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
downloadMonthlyReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadMonthlyReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
    const downloadMonthlyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadMonthlyReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
        downloadMonthlyReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadMonthlyReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PdfController::downloadMonthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
        downloadMonthlyReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadMonthlyReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadMonthlyReport.form = downloadMonthlyReportForm
/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
export const download = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/doctor/pdf/{appointment}/{type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.url = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                    type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                                type: args.type,
                }

    return download.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.get = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.head = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
    const downloadForm = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
        downloadForm.get = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
        downloadForm.head = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const PdfController = { downloadMonthlyReport, download }

export default PdfController
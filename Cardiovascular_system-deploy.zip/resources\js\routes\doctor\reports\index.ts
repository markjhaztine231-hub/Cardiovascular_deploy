import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import monthlyC7a835 from './monthly'
/**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
export const monthly = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthly.url(options),
    method: 'get',
})

monthly.definition = {
    methods: ["get","head"],
    url: '/doctor/reports/monthly',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
monthly.url = (options?: RouteQueryOptions) => {
    return monthly.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
monthly.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthly.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
monthly.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monthly.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
    const monthlyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monthly.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
        monthlyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthly.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AiController::monthly
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
        monthlyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthly.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monthly.form = monthlyForm
const reports = {
    monthly: Object.assign(monthly, monthlyC7a835),
}

export default reports
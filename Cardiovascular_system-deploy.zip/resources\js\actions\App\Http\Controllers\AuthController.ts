import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthController::create
 * @see app/Http/Controllers/AuthController.php:24
 * @route '/login'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AuthController::store
 * @see app/Http/Controllers/AuthController.php:54
 * @route '/login'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/login',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::store
 * @see app/Http/Controllers/AuthController.php:54
 * @route '/login'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::store
 * @see app/Http/Controllers/AuthController.php:54
 * @route '/login'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthController::store
 * @see app/Http/Controllers/AuthController.php:54
 * @route '/login'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthController::store
 * @see app/Http/Controllers/AuthController.php:54
 * @route '/login'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AuthController::destroy
 * @see app/Http/Controllers/AuthController.php:188
 * @route '/logout'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::destroy
 * @see app/Http/Controllers/AuthController.php:188
 * @route '/logout'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::destroy
 * @see app/Http/Controllers/AuthController.php:188
 * @route '/logout'
 */
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthController::destroy
 * @see app/Http/Controllers/AuthController.php:188
 * @route '/logout'
 */
    const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthController::destroy
 * @see app/Http/Controllers/AuthController.php:188
 * @route '/logout'
 */
        destroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(options),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
export const showResetForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showResetForm.url(args, options),
    method: 'get',
})

showResetForm.definition = {
    methods: ["get","head"],
    url: '/reset-password/{token}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
showResetForm.url = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { token: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    token: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        token: args.token,
                }

    return showResetForm.definition.url
            .replace('{token}', parsedArgs.token.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
showResetForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showResetForm.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
showResetForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showResetForm.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
    const showResetFormForm = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showResetForm.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
        showResetFormForm.get = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showResetForm.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthController::showResetForm
 * @see app/Http/Controllers/AuthController.php:202
 * @route '/reset-password/{token}'
 */
        showResetFormForm.head = (args: { token: string | number } | [token: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showResetForm.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showResetForm.form = showResetFormForm
/**
* @see \App\Http\Controllers\AuthController::sendResetLink
 * @see app/Http/Controllers/AuthController.php:208
 * @route '/forgot-password'
 */
export const sendResetLink = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

sendResetLink.definition = {
    methods: ["post"],
    url: '/forgot-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::sendResetLink
 * @see app/Http/Controllers/AuthController.php:208
 * @route '/forgot-password'
 */
sendResetLink.url = (options?: RouteQueryOptions) => {
    return sendResetLink.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::sendResetLink
 * @see app/Http/Controllers/AuthController.php:208
 * @route '/forgot-password'
 */
sendResetLink.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sendResetLink.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthController::sendResetLink
 * @see app/Http/Controllers/AuthController.php:208
 * @route '/forgot-password'
 */
    const sendResetLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sendResetLink.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthController::sendResetLink
 * @see app/Http/Controllers/AuthController.php:208
 * @route '/forgot-password'
 */
        sendResetLinkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sendResetLink.url(options),
            method: 'post',
        })
    
    sendResetLink.form = sendResetLinkForm
/**
* @see \App\Http\Controllers\AuthController::resetPassword
 * @see app/Http/Controllers/AuthController.php:243
 * @route '/reset-password'
 */
export const resetPassword = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

resetPassword.definition = {
    methods: ["post"],
    url: '/reset-password',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::resetPassword
 * @see app/Http/Controllers/AuthController.php:243
 * @route '/reset-password'
 */
resetPassword.url = (options?: RouteQueryOptions) => {
    return resetPassword.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::resetPassword
 * @see app/Http/Controllers/AuthController.php:243
 * @route '/reset-password'
 */
resetPassword.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPassword.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthController::resetPassword
 * @see app/Http/Controllers/AuthController.php:243
 * @route '/reset-password'
 */
    const resetPasswordForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetPassword.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthController::resetPassword
 * @see app/Http/Controllers/AuthController.php:243
 * @route '/reset-password'
 */
        resetPasswordForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetPassword.url(options),
            method: 'post',
        })
    
    resetPassword.form = resetPasswordForm
/**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
export const showTerms = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showTerms.url(options),
    method: 'get',
})

showTerms.definition = {
    methods: ["get","head"],
    url: '/terms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
showTerms.url = (options?: RouteQueryOptions) => {
    return showTerms.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
showTerms.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showTerms.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
showTerms.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showTerms.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
    const showTermsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showTerms.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
        showTermsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showTerms.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthController::showTerms
 * @see app/Http/Controllers/AuthController.php:45
 * @route '/terms'
 */
        showTermsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showTerms.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showTerms.form = showTermsForm
/**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
export const showRegistrationForm = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegistrationForm.url(options),
    method: 'get',
})

showRegistrationForm.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
showRegistrationForm.url = (options?: RouteQueryOptions) => {
    return showRegistrationForm.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
showRegistrationForm.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showRegistrationForm.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
showRegistrationForm.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showRegistrationForm.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
    const showRegistrationFormForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showRegistrationForm.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
        showRegistrationFormForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegistrationForm.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AuthController::showRegistrationForm
 * @see app/Http/Controllers/AuthController.php:30
 * @route '/register'
 */
        showRegistrationFormForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showRegistrationForm.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showRegistrationForm.form = showRegistrationFormForm
/**
* @see \App\Http\Controllers\AuthController::register
 * @see app/Http/Controllers/AuthController.php:128
 * @route '/register'
 */
export const register = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

register.definition = {
    methods: ["post"],
    url: '/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AuthController::register
 * @see app/Http/Controllers/AuthController.php:128
 * @route '/register'
 */
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AuthController::register
 * @see app/Http/Controllers/AuthController.php:128
 * @route '/register'
 */
register.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: register.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AuthController::register
 * @see app/Http/Controllers/AuthController.php:128
 * @route '/register'
 */
    const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: register.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AuthController::register
 * @see app/Http/Controllers/AuthController.php:128
 * @route '/register'
 */
        registerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: register.url(options),
            method: 'post',
        })
    
    register.form = registerForm
const AuthController = { create, store, destroy, showResetForm, sendResetLink, resetPassword, showTerms, showRegistrationForm, register }

export default AuthController
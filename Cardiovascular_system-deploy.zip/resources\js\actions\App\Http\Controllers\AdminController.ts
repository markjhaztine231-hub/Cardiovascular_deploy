import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
export const usersDirectory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usersDirectory.url(options),
    method: 'get',
})

usersDirectory.definition = {
    methods: ["get","head"],
    url: '/admin/users-directory',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
usersDirectory.url = (options?: RouteQueryOptions) => {
    return usersDirectory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
usersDirectory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: usersDirectory.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
usersDirectory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: usersDirectory.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
    const usersDirectoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: usersDirectory.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
        usersDirectoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usersDirectory.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::usersDirectory
 * @see app/Http/Controllers/AdminController.php:247
 * @route '/admin/users-directory'
 */
        usersDirectoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: usersDirectory.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    usersDirectory.form = usersDirectoryForm
/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
export const createAccount = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createAccount.url(options),
    method: 'get',
})

createAccount.definition = {
    methods: ["get","head"],
    url: '/admin/create-account',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.url = (options?: RouteQueryOptions) => {
    return createAccount.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createAccount.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createAccount.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
    const createAccountForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createAccount.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
        createAccountForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createAccount.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
        createAccountForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createAccount.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createAccount.form = createAccountForm
/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
export const auditLog = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditLog.url(options),
    method: 'get',
})

auditLog.definition = {
    methods: ["get","head"],
    url: '/admin/audit-log',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.url = (options?: RouteQueryOptions) => {
    return auditLog.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditLog.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: auditLog.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
    const auditLogForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: auditLog.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
        auditLogForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditLog.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
        auditLogForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditLog.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    auditLog.form = auditLogForm
/**
* @see \App\Http\Controllers\AdminController::storeUser
 * @see app/Http/Controllers/AdminController.php:100
 * @route '/admin/users'
 */
export const storeUser = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUser.url(options),
    method: 'post',
})

storeUser.definition = {
    methods: ["post"],
    url: '/admin/users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminController::storeUser
 * @see app/Http/Controllers/AdminController.php:100
 * @route '/admin/users'
 */
storeUser.url = (options?: RouteQueryOptions) => {
    return storeUser.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::storeUser
 * @see app/Http/Controllers/AdminController.php:100
 * @route '/admin/users'
 */
storeUser.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeUser.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminController::storeUser
 * @see app/Http/Controllers/AdminController.php:100
 * @route '/admin/users'
 */
    const storeUserForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeUser.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::storeUser
 * @see app/Http/Controllers/AdminController.php:100
 * @route '/admin/users'
 */
        storeUserForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeUser.url(options),
            method: 'post',
        })
    
    storeUser.form = storeUserForm
/**
* @see \App\Http\Controllers\AdminController::updateUser
 * @see app/Http/Controllers/AdminController.php:158
 * @route '/admin/users/{user}'
 */
export const updateUser = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateUser.url(args, options),
    method: 'put',
})

updateUser.definition = {
    methods: ["put"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AdminController::updateUser
 * @see app/Http/Controllers/AdminController.php:158
 * @route '/admin/users/{user}'
 */
updateUser.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return updateUser.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::updateUser
 * @see app/Http/Controllers/AdminController.php:158
 * @route '/admin/users/{user}'
 */
updateUser.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateUser.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AdminController::updateUser
 * @see app/Http/Controllers/AdminController.php:158
 * @route '/admin/users/{user}'
 */
    const updateUserForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateUser.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::updateUser
 * @see app/Http/Controllers/AdminController.php:158
 * @route '/admin/users/{user}'
 */
        updateUserForm.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateUser.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateUser.form = updateUserForm
/**
* @see \App\Http\Controllers\AdminController::deleteUser
 * @see app/Http/Controllers/AdminController.php:224
 * @route '/admin/users/{user}'
 */
export const deleteUser = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteUser.url(args, options),
    method: 'delete',
})

deleteUser.definition = {
    methods: ["delete"],
    url: '/admin/users/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AdminController::deleteUser
 * @see app/Http/Controllers/AdminController.php:224
 * @route '/admin/users/{user}'
 */
deleteUser.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return deleteUser.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::deleteUser
 * @see app/Http/Controllers/AdminController.php:224
 * @route '/admin/users/{user}'
 */
deleteUser.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteUser.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AdminController::deleteUser
 * @see app/Http/Controllers/AdminController.php:224
 * @route '/admin/users/{user}'
 */
    const deleteUserForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteUser.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::deleteUser
 * @see app/Http/Controllers/AdminController.php:224
 * @route '/admin/users/{user}'
 */
        deleteUserForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteUser.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteUser.form = deleteUserForm
/**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
export const practiceReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practiceReport.url(options),
    method: 'get',
})

practiceReport.definition = {
    methods: ["get","head"],
    url: '/admin/reports/practice',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practiceReport.url = (options?: RouteQueryOptions) => {
    return practiceReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practiceReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practiceReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practiceReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: practiceReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
    const practiceReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: practiceReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
        practiceReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practiceReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::practiceReport
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
        practiceReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practiceReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    practiceReport.form = practiceReportForm
/**
* @see \App\Http\Controllers\AdminController::generatePracticeReport
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
export const generatePracticeReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generatePracticeReport.url(options),
    method: 'post',
})

generatePracticeReport.definition = {
    methods: ["post"],
    url: '/admin/reports/practice',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminController::generatePracticeReport
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
generatePracticeReport.url = (options?: RouteQueryOptions) => {
    return generatePracticeReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::generatePracticeReport
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
generatePracticeReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generatePracticeReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminController::generatePracticeReport
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
    const generatePracticeReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generatePracticeReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::generatePracticeReport
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
        generatePracticeReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generatePracticeReport.url(options),
            method: 'post',
        })
    
    generatePracticeReport.form = generatePracticeReportForm
const AdminController = { index, usersDirectory, createAccount, auditLog, storeUser, updateUser, deleteUser, practiceReport, generatePracticeReport }

export default AdminController
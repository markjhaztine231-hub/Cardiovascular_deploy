<script setup lang="ts">
</script>

<template>
    <div class="flex items-center gap-2">
        <img 
            src="/logo.png" 
            alt="CardioCare Logo" 
            class="h-8 w-8 object-contain"
        />
        <div class="grid flex-1 text-left text-sm">
            <span class="mb-0.5 truncate leading-tight font-bold text-[#0f8c8e]"
                >CardioCare</span
            >
            <span class="text-xs text-gray-500">Cardiovascular Care System</span>
        </div>
    </div>
</template>

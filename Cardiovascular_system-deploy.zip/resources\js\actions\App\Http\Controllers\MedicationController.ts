import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationController::logDose
 * @see app/Http/Controllers/MedicationController.php:48
 * @route '/medications/{appointment}/log-dose'
 */
export const logDose = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logDose.url(args, options),
    method: 'post',
})

logDose.definition = {
    methods: ["post"],
    url: '/medications/{appointment}/log-dose',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MedicationController::logDose
 * @see app/Http/Controllers/MedicationController.php:48
 * @route '/medications/{appointment}/log-dose'
 */
logDose.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return logDose.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::logDose
 * @see app/Http/Controllers/MedicationController.php:48
 * @route '/medications/{appointment}/log-dose'
 */
logDose.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logDose.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MedicationController::logDose
 * @see app/Http/Controllers/MedicationController.php:48
 * @route '/medications/{appointment}/log-dose'
 */
    const logDoseForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logDose.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MedicationController::logDose
 * @see app/Http/Controllers/MedicationController.php:48
 * @route '/medications/{appointment}/log-dose'
 */
        logDoseForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logDose.url(args, options),
            method: 'post',
        })
    
    logDose.form = logDoseForm
/**
* @see \App\Http\Controllers\MedicationController::toggleDose
 * @see app/Http/Controllers/MedicationController.php:291
 * @route '/medications/{appointment}/toggle-dose'
 */
export const toggleDose = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleDose.url(args, options),
    method: 'post',
})

toggleDose.definition = {
    methods: ["post"],
    url: '/medications/{appointment}/toggle-dose',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MedicationController::toggleDose
 * @see app/Http/Controllers/MedicationController.php:291
 * @route '/medications/{appointment}/toggle-dose'
 */
toggleDose.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return toggleDose.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::toggleDose
 * @see app/Http/Controllers/MedicationController.php:291
 * @route '/medications/{appointment}/toggle-dose'
 */
toggleDose.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleDose.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MedicationController::toggleDose
 * @see app/Http/Controllers/MedicationController.php:291
 * @route '/medications/{appointment}/toggle-dose'
 */
    const toggleDoseForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleDose.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MedicationController::toggleDose
 * @see app/Http/Controllers/MedicationController.php:291
 * @route '/medications/{appointment}/toggle-dose'
 */
        toggleDoseForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleDose.url(args, options),
            method: 'post',
        })
    
    toggleDose.form = toggleDoseForm
/**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
export const adherence = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adherence.url(args, options),
    method: 'get',
})

adherence.definition = {
    methods: ["get","head"],
    url: '/medications/{appointment}/adherence',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
adherence.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return adherence.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
adherence.get = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: adherence.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
adherence.head = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: adherence.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
    const adherenceForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: adherence.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
        adherenceForm.get = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adherence.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationController::adherence
 * @see app/Http/Controllers/MedicationController.php:248
 * @route '/medications/{appointment}/adherence'
 */
        adherenceForm.head = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: adherence.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    adherence.form = adherenceForm
/**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
export const todayMeds = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: todayMeds.url(options),
    method: 'get',
})

todayMeds.definition = {
    methods: ["get","head"],
    url: '/patient/medications/today',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
todayMeds.url = (options?: RouteQueryOptions) => {
    return todayMeds.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
todayMeds.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: todayMeds.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
todayMeds.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: todayMeds.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
    const todayMedsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: todayMeds.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
        todayMedsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: todayMeds.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationController::todayMeds
 * @see app/Http/Controllers/MedicationController.php:344
 * @route '/patient/medications/today'
 */
        todayMedsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: todayMeds.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    todayMeds.form = todayMedsForm
/**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
export const history = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})

history.definition = {
    methods: ["get","head"],
    url: '/patient/medications/history',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
history.url = (options?: RouteQueryOptions) => {
    return history.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
history.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: history.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
history.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: history.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
    const historyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: history.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
        historyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationController::history
 * @see app/Http/Controllers/MedicationController.php:445
 * @route '/patient/medications/history'
 */
        historyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: history.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    history.form = historyForm
/**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
export const patientAdherence = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientAdherence.url(args, options),
    method: 'get',
})

patientAdherence.definition = {
    methods: ["get","head"],
    url: '/doctor/patients/{patient}/medication-adherence',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
patientAdherence.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { patient: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    patient: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        patient: typeof args.patient === 'object'
                ? args.patient.id
                : args.patient,
                }

    return patientAdherence.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
patientAdherence.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: patientAdherence.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
patientAdherence.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: patientAdherence.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
    const patientAdherenceForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: patientAdherence.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
        patientAdherenceForm.get = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientAdherence.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationController::patientAdherence
 * @see app/Http/Controllers/MedicationController.php:479
 * @route '/doctor/patients/{patient}/medication-adherence'
 */
        patientAdherenceForm.head = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: patientAdherence.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    patientAdherence.form = patientAdherenceForm
const MedicationController = { logDose, toggleDose, adherence, todayMeds, history, patientAdherence }

export default MedicationController
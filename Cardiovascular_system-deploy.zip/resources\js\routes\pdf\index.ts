import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
export const monthlyReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthlyReport.url(options),
    method: 'get',
})

monthlyReport.definition = {
    methods: ["get","head"],
    url: '/doctor/reports/monthly/pdf',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
monthlyReport.url = (options?: RouteQueryOptions) => {
    return monthlyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
monthlyReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: monthlyReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
monthlyReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: monthlyReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
    const monthlyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: monthlyReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
        monthlyReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthlyReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PdfController::monthlyReport
 * @see app/Http/Controllers/PdfController.php:117
 * @route '/doctor/reports/monthly/pdf'
 */
        monthlyReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: monthlyReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    monthlyReport.form = monthlyReportForm
/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
export const download = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/doctor/pdf/{appointment}/{type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.url = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                    type: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                                type: args.type,
                }

    return download.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace('{type}', parsedArgs.type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.get = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
download.head = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
    const downloadForm = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
        downloadForm.get = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PdfController::download
 * @see app/Http/Controllers/PdfController.php:24
 * @route '/doctor/pdf/{appointment}/{type}'
 */
        downloadForm.head = (args: { appointment: number | { id: number }, type: string | number } | [appointment: number | { id: number }, type: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const pdf = {
    monthlyReport: Object.assign(monthlyReport, monthlyReport),
download: Object.assign(download, download),
}

export default pdf
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AiController::narrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
export const narrative = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: narrative.url(options),
    method: 'put',
})

narrative.definition = {
    methods: ["put"],
    url: '/doctor/reports/monthly/narrative',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AiController::narrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
narrative.url = (options?: RouteQueryOptions) => {
    return narrative.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::narrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
narrative.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: narrative.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AiController::narrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
    const narrativeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: narrative.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::narrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
        narrativeForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: narrative.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    narrative.form = narrativeForm
const monthly = {
    narrative: Object.assign(narrative, narrative),
}

export default monthly
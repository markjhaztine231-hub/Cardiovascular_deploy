import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import patient from './patient'
import reports from './reports'
/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/doctor/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::dashboard
 * @see app/Http/Controllers/DoctorController.php:17
 * @route '/doctor/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
export const emr = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emr.url(options),
    method: 'get',
})

emr.definition = {
    methods: ["get","head"],
    url: '/doctor/emr',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.url = (options?: RouteQueryOptions) => {
    return emr.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: emr.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
emr.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: emr.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
    const emrForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: emr.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
        emrForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emr.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorController::emr
 * @see app/Http/Controllers/DoctorController.php:74
 * @route '/doctor/emr'
 */
        emrForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: emr.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    emr.form = emrForm
const doctor = {
    dashboard: Object.assign(dashboard, dashboard),
emr: Object.assign(emr, emr),
patient: Object.assign(patient, patient),
reports: Object.assign(reports, reports),
}

export default doctor
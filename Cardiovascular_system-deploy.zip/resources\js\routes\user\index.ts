import profile from './profile'
const user = {
    profile: Object.assign(profile, profile),
}

export default user
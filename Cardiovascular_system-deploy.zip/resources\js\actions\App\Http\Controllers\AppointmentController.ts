import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AppointmentController::storeSchedule
 * @see app/Http/Controllers/AppointmentController.php:911
 * @route '/receptionist/schedules'
 */
export const storeSchedule = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSchedule.url(options),
    method: 'post',
})

storeSchedule.definition = {
    methods: ["post"],
    url: '/receptionist/schedules',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::storeSchedule
 * @see app/Http/Controllers/AppointmentController.php:911
 * @route '/receptionist/schedules'
 */
storeSchedule.url = (options?: RouteQueryOptions) => {
    return storeSchedule.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::storeSchedule
 * @see app/Http/Controllers/AppointmentController.php:911
 * @route '/receptionist/schedules'
 */
storeSchedule.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSchedule.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::storeSchedule
 * @see app/Http/Controllers/AppointmentController.php:911
 * @route '/receptionist/schedules'
 */
    const storeScheduleForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSchedule.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::storeSchedule
 * @see app/Http/Controllers/AppointmentController.php:911
 * @route '/receptionist/schedules'
 */
        storeScheduleForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSchedule.url(options),
            method: 'post',
        })
    
    storeSchedule.form = storeScheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::updateSchedule
 * @see app/Http/Controllers/AppointmentController.php:941
 * @route '/receptionist/schedules/{schedule}'
 */
export const updateSchedule = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSchedule.url(args, options),
    method: 'put',
})

updateSchedule.definition = {
    methods: ["put"],
    url: '/receptionist/schedules/{schedule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::updateSchedule
 * @see app/Http/Controllers/AppointmentController.php:941
 * @route '/receptionist/schedules/{schedule}'
 */
updateSchedule.url = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { schedule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { schedule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        schedule: typeof args.schedule === 'object'
                ? args.schedule.id
                : args.schedule,
                }

    return updateSchedule.definition.url
            .replace('{schedule}', parsedArgs.schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::updateSchedule
 * @see app/Http/Controllers/AppointmentController.php:941
 * @route '/receptionist/schedules/{schedule}'
 */
updateSchedule.put = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSchedule.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::updateSchedule
 * @see app/Http/Controllers/AppointmentController.php:941
 * @route '/receptionist/schedules/{schedule}'
 */
    const updateScheduleForm = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSchedule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::updateSchedule
 * @see app/Http/Controllers/AppointmentController.php:941
 * @route '/receptionist/schedules/{schedule}'
 */
        updateScheduleForm.put = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSchedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSchedule.form = updateScheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::deleteSchedule
 * @see app/Http/Controllers/AppointmentController.php:971
 * @route '/receptionist/schedules/{schedule}'
 */
export const deleteSchedule = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteSchedule.url(args, options),
    method: 'delete',
})

deleteSchedule.definition = {
    methods: ["delete"],
    url: '/receptionist/schedules/{schedule}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AppointmentController::deleteSchedule
 * @see app/Http/Controllers/AppointmentController.php:971
 * @route '/receptionist/schedules/{schedule}'
 */
deleteSchedule.url = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { schedule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { schedule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    schedule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        schedule: typeof args.schedule === 'object'
                ? args.schedule.id
                : args.schedule,
                }

    return deleteSchedule.definition.url
            .replace('{schedule}', parsedArgs.schedule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::deleteSchedule
 * @see app/Http/Controllers/AppointmentController.php:971
 * @route '/receptionist/schedules/{schedule}'
 */
deleteSchedule.delete = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: deleteSchedule.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AppointmentController::deleteSchedule
 * @see app/Http/Controllers/AppointmentController.php:971
 * @route '/receptionist/schedules/{schedule}'
 */
    const deleteScheduleForm = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: deleteSchedule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::deleteSchedule
 * @see app/Http/Controllers/AppointmentController.php:971
 * @route '/receptionist/schedules/{schedule}'
 */
        deleteScheduleForm.delete = (args: { schedule: number | { id: number } } | [schedule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: deleteSchedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    deleteSchedule.form = deleteScheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/patient/appointments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
export const availableSlots = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableSlots.url(options),
    method: 'get',
})

availableSlots.definition = {
    methods: ["get","head"],
    url: '/patient/appointments/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availableSlots.url = (options?: RouteQueryOptions) => {
    return availableSlots.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availableSlots.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableSlots.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availableSlots.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableSlots.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
    const availableSlotsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availableSlots.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
        availableSlotsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableSlots.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::availableSlots
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
        availableSlotsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availableSlots.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availableSlots.form = availableSlotsForm
/**
* @see \App\Http\Controllers\AppointmentController::cancelAppointment
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
export const cancelAppointment = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelAppointment.url(args, options),
    method: 'post',
})

cancelAppointment.definition = {
    methods: ["post"],
    url: '/patient/appointments/{appointment}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::cancelAppointment
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
cancelAppointment.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return cancelAppointment.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::cancelAppointment
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
cancelAppointment.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancelAppointment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::cancelAppointment
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
    const cancelAppointmentForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancelAppointment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::cancelAppointment
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
        cancelAppointmentForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancelAppointment.url(args, options),
            method: 'post',
        })
    
    cancelAppointment.form = cancelAppointmentForm
/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
export const requestReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestReschedule.url(args, options),
    method: 'post',
})

requestReschedule.definition = {
    methods: ["post"],
    url: '/patient/appointments/{appointment}/request-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
requestReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return requestReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
requestReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
    const requestRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
        requestRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestReschedule.url(args, options),
            method: 'post',
        })
    
    requestReschedule.form = requestRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
export const approveReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveReschedule.url(args, options),
    method: 'post',
})

approveReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/approve-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
approveReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return approveReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
approveReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
    const approveRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
        approveRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveReschedule.url(args, options),
            method: 'post',
        })
    
    approveReschedule.form = approveRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
export const denyReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: denyReschedule.url(args, options),
    method: 'post',
})

denyReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/deny-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
denyReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return denyReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
denyReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: denyReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
    const denyRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: denyReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
        denyRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: denyReschedule.url(args, options),
            method: 'post',
        })
    
    denyReschedule.form = denyRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
export const editReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editReschedule.url(args, options),
    method: 'post',
})

editReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/edit-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
editReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return editReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
editReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
    const editRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
        editRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editReschedule.url(args, options),
            method: 'post',
        })
    
    editReschedule.form = editRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::storeFollowUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
export const storeFollowUp = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFollowUp.url(args, options),
    method: 'post',
})

storeFollowUp.definition = {
    methods: ["post"],
    url: '/appointments/{appointment}/follow-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::storeFollowUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
storeFollowUp.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return storeFollowUp.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::storeFollowUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
storeFollowUp.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeFollowUp.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::storeFollowUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
    const storeFollowUpForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeFollowUp.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::storeFollowUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
        storeFollowUpForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeFollowUp.url(args, options),
            method: 'post',
        })
    
    storeFollowUp.form = storeFollowUpForm
/**
* @see \App\Http\Controllers\AppointmentController::updateStatus
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
export const updateStatus = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

updateStatus.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/status',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::updateStatus
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
updateStatus.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return updateStatus.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::updateStatus
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
updateStatus.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateStatus.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::updateStatus
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
    const updateStatusForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::updateStatus
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
        updateStatusForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/appointments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AppointmentController::storeManual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
export const storeManual = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeManual.url(options),
    method: 'post',
})

storeManual.definition = {
    methods: ["post"],
    url: '/appointments/manual',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::storeManual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
storeManual.url = (options?: RouteQueryOptions) => {
    return storeManual.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::storeManual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
storeManual.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeManual.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::storeManual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
    const storeManualForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeManual.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::storeManual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
        storeManualForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeManual.url(options),
            method: 'post',
        })
    
    storeManual.form = storeManualForm
/**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
export const createReturning = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createReturning.url(options),
    method: 'get',
})

createReturning.definition = {
    methods: ["get","head"],
    url: '/appointments/returning',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
createReturning.url = (options?: RouteQueryOptions) => {
    return createReturning.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
createReturning.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createReturning.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
createReturning.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createReturning.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
    const createReturningForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createReturning.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
        createReturningForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createReturning.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::createReturning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
        createReturningForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createReturning.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createReturning.form = createReturningForm
/**
* @see \App\Http\Controllers\AppointmentController::storeReturning
 * @see app/Http/Controllers/AppointmentController.php:368
 * @route '/appointments/returning'
 */
export const storeReturning = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReturning.url(options),
    method: 'post',
})

storeReturning.definition = {
    methods: ["post"],
    url: '/appointments/returning',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::storeReturning
 * @see app/Http/Controllers/AppointmentController.php:368
 * @route '/appointments/returning'
 */
storeReturning.url = (options?: RouteQueryOptions) => {
    return storeReturning.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::storeReturning
 * @see app/Http/Controllers/AppointmentController.php:368
 * @route '/appointments/returning'
 */
storeReturning.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeReturning.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::storeReturning
 * @see app/Http/Controllers/AppointmentController.php:368
 * @route '/appointments/returning'
 */
    const storeReturningForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeReturning.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::storeReturning
 * @see app/Http/Controllers/AppointmentController.php:368
 * @route '/appointments/returning'
 */
        storeReturningForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeReturning.url(options),
            method: 'post',
        })
    
    storeReturning.form = storeReturningForm
/**
* @see \App\Http\Controllers\AppointmentController::completeConsultation
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
export const completeConsultation = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeConsultation.url(args, options),
    method: 'post',
})

completeConsultation.definition = {
    methods: ["post"],
    url: '/appointments/{appointment}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::completeConsultation
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
completeConsultation.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return completeConsultation.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::completeConsultation
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
completeConsultation.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: completeConsultation.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::completeConsultation
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
    const completeConsultationForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: completeConsultation.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::completeConsultation
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
        completeConsultationForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: completeConsultation.url(args, options),
            method: 'post',
        })
    
    completeConsultation.form = completeConsultationForm
/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
export const transfer = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: transfer.url(args, options),
    method: 'put',
})

transfer.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/transfer',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
transfer.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return transfer.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
transfer.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: transfer.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
    const transferForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: transfer.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
        transferForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: transfer.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    transfer.form = transferForm
/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
export const reschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reschedule.url(args, options),
    method: 'put',
})

reschedule.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/reschedule',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
reschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return reschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
reschedule.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reschedule.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
    const rescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reschedule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
        rescheduleForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reschedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reschedule.form = rescheduleForm
const AppointmentController = { storeSchedule, updateSchedule, deleteSchedule, store, availableSlots, cancelAppointment, requestReschedule, approveReschedule, denyReschedule, editReschedule, storeFollowUp, updateStatus, create, storeManual, createReturning, storeReturning, completeConsultation, transfer, reschedule }

export default AppointmentController
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/patient/appointments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::store
 * @see app/Http/Controllers/AppointmentController.php:38
 * @route '/patient/appointments'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
export const availability = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})

availability.definition = {
    methods: ["get","head"],
    url: '/patient/appointments/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availability.url = (options?: RouteQueryOptions) => {
    return availability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availability.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
availability.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availability.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
    const availabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availability.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
        availabilityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::availability
 * @see app/Http/Controllers/AppointmentController.php:119
 * @route '/patient/appointments/availability'
 */
        availabilityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availability.form = availabilityForm
/**
* @see \App\Http\Controllers\AppointmentController::cancel
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
export const cancel = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/patient/appointments/{appointment}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::cancel
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
cancel.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return cancel.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::cancel
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
cancel.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::cancel
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
    const cancelForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::cancel
 * @see app/Http/Controllers/AppointmentController.php:174
 * @route '/patient/appointments/{appointment}/cancel'
 */
        cancelForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
export const requestReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestReschedule.url(args, options),
    method: 'post',
})

requestReschedule.definition = {
    methods: ["post"],
    url: '/patient/appointments/{appointment}/request-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
requestReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return requestReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
requestReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: requestReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
    const requestRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: requestReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::requestReschedule
 * @see app/Http/Controllers/AppointmentController.php:1041
 * @route '/patient/appointments/{appointment}/request-reschedule'
 */
        requestRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: requestReschedule.url(args, options),
            method: 'post',
        })
    
    requestReschedule.form = requestRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
export const approveReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveReschedule.url(args, options),
    method: 'post',
})

approveReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/approve-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
approveReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return approveReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
approveReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
    const approveRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::approveReschedule
 * @see app/Http/Controllers/AppointmentController.php:1071
 * @route '/receptionist/appointments/{appointment}/approve-reschedule'
 */
        approveRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveReschedule.url(args, options),
            method: 'post',
        })
    
    approveReschedule.form = approveRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
export const denyReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: denyReschedule.url(args, options),
    method: 'post',
})

denyReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/deny-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
denyReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return denyReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
denyReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: denyReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
    const denyRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: denyReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::denyReschedule
 * @see app/Http/Controllers/AppointmentController.php:1200
 * @route '/receptionist/appointments/{appointment}/deny-reschedule'
 */
        denyRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: denyReschedule.url(args, options),
            method: 'post',
        })
    
    denyReschedule.form = denyRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
export const editReschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editReschedule.url(args, options),
    method: 'post',
})

editReschedule.definition = {
    methods: ["post"],
    url: '/receptionist/appointments/{appointment}/edit-reschedule',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
editReschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return editReschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
editReschedule.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: editReschedule.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
    const editRescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: editReschedule.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::editReschedule
 * @see app/Http/Controllers/AppointmentController.php:1130
 * @route '/receptionist/appointments/{appointment}/edit-reschedule'
 */
        editRescheduleForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: editReschedule.url(args, options),
            method: 'post',
        })
    
    editReschedule.form = editRescheduleForm
/**
* @see \App\Http\Controllers\AppointmentController::followUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
export const followUp = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: followUp.url(args, options),
    method: 'post',
})

followUp.definition = {
    methods: ["post"],
    url: '/appointments/{appointment}/follow-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::followUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
followUp.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return followUp.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::followUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
followUp.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: followUp.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::followUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
    const followUpForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: followUp.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::followUp
 * @see app/Http/Controllers/AppointmentController.php:1220
 * @route '/appointments/{appointment}/follow-up'
 */
        followUpForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: followUp.url(args, options),
            method: 'post',
        })
    
    followUp.form = followUpForm
/**
* @see \App\Http\Controllers\AppointmentController::status
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
export const status = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: status.url(args, options),
    method: 'put',
})

status.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/status',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::status
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
status.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return status.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::status
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
status.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: status.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::status
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
    const statusForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: status.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::status
 * @see app/Http/Controllers/AppointmentController.php:204
 * @route '/appointments/{appointment}/status'
 */
        statusForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: status.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    status.form = statusForm
/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/appointments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::create
 * @see app/Http/Controllers/AppointmentController.php:229
 * @route '/appointments/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AppointmentController::manual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
export const manual = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manual.url(options),
    method: 'post',
})

manual.definition = {
    methods: ["post"],
    url: '/appointments/manual',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::manual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
manual.url = (options?: RouteQueryOptions) => {
    return manual.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::manual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
manual.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: manual.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::manual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
    const manualForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: manual.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::manual
 * @see app/Http/Controllers/AppointmentController.php:248
 * @route '/appointments/manual'
 */
        manualForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: manual.url(options),
            method: 'post',
        })
    
    manual.form = manualForm
/**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
export const returning = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returning.url(options),
    method: 'get',
})

returning.definition = {
    methods: ["get","head"],
    url: '/appointments/returning',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
returning.url = (options?: RouteQueryOptions) => {
    return returning.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
returning.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returning.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
returning.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: returning.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
    const returningForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: returning.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
        returningForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returning.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AppointmentController::returning
 * @see app/Http/Controllers/AppointmentController.php:338
 * @route '/appointments/returning'
 */
        returningForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returning.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    returning.form = returningForm
/**
* @see \App\Http\Controllers\AppointmentController::complete
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
export const complete = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/appointments/{appointment}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AppointmentController::complete
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
complete.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return complete.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::complete
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
complete.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AppointmentController::complete
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
    const completeForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::complete
 * @see app/Http/Controllers/AppointmentController.php:432
 * @route '/appointments/{appointment}/complete'
 */
        completeForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
export const transfer = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: transfer.url(args, options),
    method: 'put',
})

transfer.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/transfer',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
transfer.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return transfer.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
transfer.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: transfer.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
    const transferForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: transfer.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::transfer
 * @see app/Http/Controllers/AppointmentController.php:893
 * @route '/appointments/{appointment}/transfer'
 */
        transferForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: transfer.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    transfer.form = transferForm
/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
export const reschedule = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reschedule.url(args, options),
    method: 'put',
})

reschedule.definition = {
    methods: ["put"],
    url: '/appointments/{appointment}/reschedule',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
reschedule.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return reschedule.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
reschedule.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: reschedule.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
    const rescheduleForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reschedule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AppointmentController::reschedule
 * @see app/Http/Controllers/AppointmentController.php:1273
 * @route '/appointments/{appointment}/reschedule'
 */
        rescheduleForm.put = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reschedule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reschedule.form = rescheduleForm
const appointments = {
    store: Object.assign(store, store),
availability: Object.assign(availability, availability),
cancel: Object.assign(cancel, cancel),
requestReschedule: Object.assign(requestReschedule, requestReschedule),
approveReschedule: Object.assign(approveReschedule, approveReschedule),
denyReschedule: Object.assign(denyReschedule, denyReschedule),
editReschedule: Object.assign(editReschedule, editReschedule),
followUp: Object.assign(followUp, followUp),
status: Object.assign(status, status),
create: Object.assign(create, create),
manual: Object.assign(manual, manual),
returning: Object.assign(returning, returning),
complete: Object.assign(complete, complete),
transfer: Object.assign(transfer, transfer),
reschedule: Object.assign(reschedule, reschedule),
}

export default appointments
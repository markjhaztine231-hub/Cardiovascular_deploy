import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
export const show = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/doctor/appointments/{appointment}/consultation',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
show.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return show.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
show.get = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
show.head = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
    const showForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
        showForm.get = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\DoctorConsultationController::show
 * @see app/Http/Controllers/DoctorConsultationController.php:17
 * @route '/doctor/appointments/{appointment}/consultation'
 */
        showForm.head = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\DoctorConsultationController::start
 * @see app/Http/Controllers/DoctorConsultationController.php:46
 * @route '/doctor/appointments/{appointment}/consultation/start'
 */
export const start = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/doctor/appointments/{appointment}/consultation/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DoctorConsultationController::start
 * @see app/Http/Controllers/DoctorConsultationController.php:46
 * @route '/doctor/appointments/{appointment}/consultation/start'
 */
start.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return start.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DoctorConsultationController::start
 * @see app/Http/Controllers/DoctorConsultationController.php:46
 * @route '/doctor/appointments/{appointment}/consultation/start'
 */
start.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DoctorConsultationController::start
 * @see app/Http/Controllers/DoctorConsultationController.php:46
 * @route '/doctor/appointments/{appointment}/consultation/start'
 */
    const startForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DoctorConsultationController::start
 * @see app/Http/Controllers/DoctorConsultationController.php:46
 * @route '/doctor/appointments/{appointment}/consultation/start'
 */
        startForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
const DoctorConsultationController = { show, start }

export default DoctorConsultationController
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import users from './users'
import reports from './reports'
/**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::dashboard
 * @see app/Http/Controllers/AdminController.php:28
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
export const createAccount = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createAccount.url(options),
    method: 'get',
})

createAccount.definition = {
    methods: ["get","head"],
    url: '/admin/create-account',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.url = (options?: RouteQueryOptions) => {
    return createAccount.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createAccount.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
createAccount.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createAccount.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
    const createAccountForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createAccount.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
        createAccountForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createAccount.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::createAccount
 * @see app/Http/Controllers/AdminController.php:300
 * @route '/admin/create-account'
 */
        createAccountForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createAccount.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createAccount.form = createAccountForm
/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
export const auditLog = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditLog.url(options),
    method: 'get',
})

auditLog.definition = {
    methods: ["get","head"],
    url: '/admin/audit-log',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.url = (options?: RouteQueryOptions) => {
    return auditLog.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: auditLog.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
auditLog.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: auditLog.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
    const auditLogForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: auditLog.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
        auditLogForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditLog.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::auditLog
 * @see app/Http/Controllers/AdminController.php:311
 * @route '/admin/audit-log'
 */
        auditLogForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: auditLog.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    auditLog.form = auditLogForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
users: Object.assign(users, users),
createAccount: Object.assign(createAccount, createAccount),
auditLog: Object.assign(auditLog, auditLog),
reports: Object.assign(reports, reports),
}

export default admin
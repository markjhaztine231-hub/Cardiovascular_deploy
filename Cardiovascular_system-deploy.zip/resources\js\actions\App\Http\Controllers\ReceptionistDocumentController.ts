import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::store
 * @see app/Http/Controllers/ReceptionistDocumentController.php:15
 * @route '/appointments/{appointment}/documents'
 */
export const store = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/appointments/{appointment}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::store
 * @see app/Http/Controllers/ReceptionistDocumentController.php:15
 * @route '/appointments/{appointment}/documents'
 */
store.url = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { appointment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { appointment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    appointment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        appointment: typeof args.appointment === 'object'
                ? args.appointment.id
                : args.appointment,
                }

    return store.definition.url
            .replace('{appointment}', parsedArgs.appointment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::store
 * @see app/Http/Controllers/ReceptionistDocumentController.php:15
 * @route '/appointments/{appointment}/documents'
 */
store.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReceptionistDocumentController::store
 * @see app/Http/Controllers/ReceptionistDocumentController.php:15
 * @route '/appointments/{appointment}/documents'
 */
    const storeForm = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::store
 * @see app/Http/Controllers/ReceptionistDocumentController.php:15
 * @route '/appointments/{appointment}/documents'
 */
        storeForm.post = (args: { appointment: number | { id: number } } | [appointment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
export const pending = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})

pending.definition = {
    methods: ["get","head"],
    url: '/documents/pending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
pending.url = (options?: RouteQueryOptions) => {
    return pending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
pending.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
pending.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pending.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
    const pendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pending.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
        pendingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pending.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::pending
 * @see app/Http/Controllers/ReceptionistDocumentController.php:121
 * @route '/documents/pending'
 */
        pendingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pending.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pending.form = pendingForm
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
export const show = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/documents/{document}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
show.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return show.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
show.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
show.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
    const showForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
        showForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::show
 * @see app/Http/Controllers/ReceptionistDocumentController.php:48
 * @route '/documents/{document}'
 */
        showForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ReceptionistDocumentController::retryOcr
 * @see app/Http/Controllers/ReceptionistDocumentController.php:65
 * @route '/documents/{document}/retry-ocr'
 */
export const retryOcr = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retryOcr.url(args, options),
    method: 'post',
})

retryOcr.definition = {
    methods: ["post"],
    url: '/documents/{document}/retry-ocr',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::retryOcr
 * @see app/Http/Controllers/ReceptionistDocumentController.php:65
 * @route '/documents/{document}/retry-ocr'
 */
retryOcr.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return retryOcr.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReceptionistDocumentController::retryOcr
 * @see app/Http/Controllers/ReceptionistDocumentController.php:65
 * @route '/documents/{document}/retry-ocr'
 */
retryOcr.post = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: retryOcr.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ReceptionistDocumentController::retryOcr
 * @see app/Http/Controllers/ReceptionistDocumentController.php:65
 * @route '/documents/{document}/retry-ocr'
 */
    const retryOcrForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: retryOcr.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ReceptionistDocumentController::retryOcr
 * @see app/Http/Controllers/ReceptionistDocumentController.php:65
 * @route '/documents/{document}/retry-ocr'
 */
        retryOcrForm.post = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: retryOcr.url(args, options),
            method: 'post',
        })
    
    retryOcr.form = retryOcrForm
const ReceptionistDocumentController = { store, pending, show, retryOcr }

export default ReceptionistDocumentController
import AuthController from './AuthController'
import ReceptionistController from './ReceptionistController'
import AppointmentController from './AppointmentController'
import DoctorController from './DoctorController'
import AiController from './AiController'
import AdminController from './AdminController'
import ProfileController from './ProfileController'
import MedicationController from './MedicationController'
import ReceptionistDocumentController from './ReceptionistDocumentController'
import DoctorConsultationController from './DoctorConsultationController'
import PdfController from './PdfController'
import Settings from './Settings'
const Controllers = {
    AuthController: Object.assign(AuthController, AuthController),
ReceptionistController: Object.assign(ReceptionistController, ReceptionistController),
AppointmentController: Object.assign(AppointmentController, AppointmentController),
DoctorController: Object.assign(DoctorController, DoctorController),
AiController: Object.assign(AiController, AiController),
AdminController: Object.assign(AdminController, AdminController),
ProfileController: Object.assign(ProfileController, ProfileController),
MedicationController: Object.assign(MedicationController, MedicationController),
ReceptionistDocumentController: Object.assign(ReceptionistDocumentController, ReceptionistDocumentController),
DoctorConsultationController: Object.assign(DoctorConsultationController, DoctorConsultationController),
PdfController: Object.assign(PdfController, PdfController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers
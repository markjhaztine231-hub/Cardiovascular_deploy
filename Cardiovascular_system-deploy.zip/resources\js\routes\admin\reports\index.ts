import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import practice58e2df from './practice'
/**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
export const practice = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practice.url(options),
    method: 'get',
})

practice.definition = {
    methods: ["get","head"],
    url: '/admin/reports/practice',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practice.url = (options?: RouteQueryOptions) => {
    return practice.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practice.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practice.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
practice.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: practice.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
    const practiceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: practice.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
        practiceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practice.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::practice
 * @see app/Http/Controllers/AdminController.php:358
 * @route '/admin/reports/practice'
 */
        practiceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practice.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    practice.form = practiceForm
const reports = {
    practice: Object.assign(practice, practice58e2df),
}

export default reports
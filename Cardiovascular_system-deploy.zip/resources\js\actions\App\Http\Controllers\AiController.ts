import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AiController::generateAbstract
 * @see app/Http/Controllers/AiController.php:26
 * @route '/api/ai/abstract/{patient}'
 */
export const generateAbstract = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateAbstract.url(args, options),
    method: 'post',
})

generateAbstract.definition = {
    methods: ["post"],
    url: '/api/ai/abstract/{patient}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AiController::generateAbstract
 * @see app/Http/Controllers/AiController.php:26
 * @route '/api/ai/abstract/{patient}'
 */
generateAbstract.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { patient: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    patient: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        patient: typeof args.patient === 'object'
                ? args.patient.id
                : args.patient,
                }

    return generateAbstract.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::generateAbstract
 * @see app/Http/Controllers/AiController.php:26
 * @route '/api/ai/abstract/{patient}'
 */
generateAbstract.post = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateAbstract.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AiController::generateAbstract
 * @see app/Http/Controllers/AiController.php:26
 * @route '/api/ai/abstract/{patient}'
 */
    const generateAbstractForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateAbstract.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::generateAbstract
 * @see app/Http/Controllers/AiController.php:26
 * @route '/api/ai/abstract/{patient}'
 */
        generateAbstractForm.post = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateAbstract.url(args, options),
            method: 'post',
        })
    
    generateAbstract.form = generateAbstractForm
/**
* @see \App\Http\Controllers\AiController::submitFeedback
 * @see app/Http/Controllers/AiController.php:198
 * @route '/api/ai/feedback/{patient}'
 */
export const submitFeedback = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitFeedback.url(args, options),
    method: 'post',
})

submitFeedback.definition = {
    methods: ["post"],
    url: '/api/ai/feedback/{patient}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AiController::submitFeedback
 * @see app/Http/Controllers/AiController.php:198
 * @route '/api/ai/feedback/{patient}'
 */
submitFeedback.url = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { patient: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { patient: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    patient: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        patient: typeof args.patient === 'object'
                ? args.patient.id
                : args.patient,
                }

    return submitFeedback.definition.url
            .replace('{patient}', parsedArgs.patient.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::submitFeedback
 * @see app/Http/Controllers/AiController.php:198
 * @route '/api/ai/feedback/{patient}'
 */
submitFeedback.post = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitFeedback.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AiController::submitFeedback
 * @see app/Http/Controllers/AiController.php:198
 * @route '/api/ai/feedback/{patient}'
 */
    const submitFeedbackForm = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submitFeedback.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::submitFeedback
 * @see app/Http/Controllers/AiController.php:198
 * @route '/api/ai/feedback/{patient}'
 */
        submitFeedbackForm.post = (args: { patient: number | { id: number } } | [patient: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submitFeedback.url(args, options),
            method: 'post',
        })
    
    submitFeedback.form = submitFeedbackForm
/**
* @see \App\Http\Controllers\AiController::verifyAndLearnReport
 * @see app/Http/Controllers/AiController.php:167
 * @route '/api/ai/verify-report'
 */
export const verifyAndLearnReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyAndLearnReport.url(options),
    method: 'post',
})

verifyAndLearnReport.definition = {
    methods: ["post"],
    url: '/api/ai/verify-report',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AiController::verifyAndLearnReport
 * @see app/Http/Controllers/AiController.php:167
 * @route '/api/ai/verify-report'
 */
verifyAndLearnReport.url = (options?: RouteQueryOptions) => {
    return verifyAndLearnReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::verifyAndLearnReport
 * @see app/Http/Controllers/AiController.php:167
 * @route '/api/ai/verify-report'
 */
verifyAndLearnReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verifyAndLearnReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AiController::verifyAndLearnReport
 * @see app/Http/Controllers/AiController.php:167
 * @route '/api/ai/verify-report'
 */
    const verifyAndLearnReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verifyAndLearnReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::verifyAndLearnReport
 * @see app/Http/Controllers/AiController.php:167
 * @route '/api/ai/verify-report'
 */
        verifyAndLearnReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verifyAndLearnReport.url(options),
            method: 'post',
        })
    
    verifyAndLearnReport.form = verifyAndLearnReportForm
/**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
export const showMonthlyReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showMonthlyReport.url(options),
    method: 'get',
})

showMonthlyReport.definition = {
    methods: ["get","head"],
    url: '/doctor/reports/monthly',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
showMonthlyReport.url = (options?: RouteQueryOptions) => {
    return showMonthlyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
showMonthlyReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showMonthlyReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
showMonthlyReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showMonthlyReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
    const showMonthlyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showMonthlyReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
        showMonthlyReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showMonthlyReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AiController::showMonthlyReport
 * @see app/Http/Controllers/AiController.php:81
 * @route '/doctor/reports/monthly'
 */
        showMonthlyReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showMonthlyReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showMonthlyReport.form = showMonthlyReportForm
/**
* @see \App\Http\Controllers\AiController::generateMonthlyReport
 * @see app/Http/Controllers/AiController.php:99
 * @route '/doctor/reports/monthly'
 */
export const generateMonthlyReport = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateMonthlyReport.url(options),
    method: 'post',
})

generateMonthlyReport.definition = {
    methods: ["post"],
    url: '/doctor/reports/monthly',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AiController::generateMonthlyReport
 * @see app/Http/Controllers/AiController.php:99
 * @route '/doctor/reports/monthly'
 */
generateMonthlyReport.url = (options?: RouteQueryOptions) => {
    return generateMonthlyReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::generateMonthlyReport
 * @see app/Http/Controllers/AiController.php:99
 * @route '/doctor/reports/monthly'
 */
generateMonthlyReport.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateMonthlyReport.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AiController::generateMonthlyReport
 * @see app/Http/Controllers/AiController.php:99
 * @route '/doctor/reports/monthly'
 */
    const generateMonthlyReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateMonthlyReport.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::generateMonthlyReport
 * @see app/Http/Controllers/AiController.php:99
 * @route '/doctor/reports/monthly'
 */
        generateMonthlyReportForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateMonthlyReport.url(options),
            method: 'post',
        })
    
    generateMonthlyReport.form = generateMonthlyReportForm
/**
* @see \App\Http\Controllers\AiController::updateNarrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
export const updateNarrative = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateNarrative.url(options),
    method: 'put',
})

updateNarrative.definition = {
    methods: ["put"],
    url: '/doctor/reports/monthly/narrative',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AiController::updateNarrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
updateNarrative.url = (options?: RouteQueryOptions) => {
    return updateNarrative.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AiController::updateNarrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
updateNarrative.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateNarrative.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\AiController::updateNarrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
    const updateNarrativeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateNarrative.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AiController::updateNarrative
 * @see app/Http/Controllers/AiController.php:177
 * @route '/doctor/reports/monthly/narrative'
 */
        updateNarrativeForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateNarrative.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateNarrative.form = updateNarrativeForm
const AiController = { generateAbstract, submitFeedback, verifyAndLearnReport, showMonthlyReport, generateMonthlyReport, updateNarrative }

export default AiController
import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminController::generate
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/admin/reports/practice',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminController::generate
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::generate
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminController::generate
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::generate
 * @see app/Http/Controllers/AdminController.php:409
 * @route '/admin/reports/practice'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const practice = {
    generate: Object.assign(generate, generate),
}

export default practice